# terminal-site
a linux based terminal site (html js and css only)
Live of this site is https://www.youtube.com/watch?v=5uZwlcHBp_I
